const express = require('express');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

const services = [
  { id: 'electrical', name: 'Electrician', nameHi: 'इलेक्ट्रिशियन' },
  { id: 'plumbing', name: 'Plumbing', nameHi: 'प्लंबर' },
  { id: 'appliance', name: 'Appliance Repair', nameHi: 'AC एवं उपकरण' },
  { id: 'cleaning', name: 'Cleaning', nameHi: 'हाउस क्लीनिंग' },
  { id: 'carpentry', name: 'Carpentry', nameHi: 'कारपेंटर' },
  { id: 'painting', name: 'Painting', nameHi: 'पेंटिंग' },
  { id: 'vehicle', name: 'Vehicle Services', nameHi: 'वाहन सेवाएँ' },
  { id: 'it', name: 'Computer & IT', nameHi: 'कंप्यूटर एवं IT' }
];

const bookings = [];

app.get('/health', (_req, res) => res.json({ ok: true, app: 'SEVANEX API', version: '0.1.0' }));
app.get('/api/v1/services', (_req, res) => res.json({ city: 'Singrauli', services }));
app.get('/api/v1/bookings', (_req, res) => res.json({ bookings }));

app.post('/api/v1/bookings', (req, res) => {
  const { serviceId, customerName, phone, address, description } = req.body || {};
  if (!serviceId || !address) {
    return res.status(400).json({ error: 'serviceId and address are required' });
  }
  const booking = {
    id: `SVX-${Date.now()}`,
    serviceId,
    customerName: customerName || 'Customer',
    phone: phone || null,
    address,
    description: description || '',
    city: 'Singrauli',
    status: 'requested',
    createdAt: new Date().toISOString()
  };
  bookings.unshift(booking);
  res.status(201).json({ booking });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`SEVANEX API listening on ${port}`));
