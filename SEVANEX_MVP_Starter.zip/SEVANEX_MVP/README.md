# SEVANEX — Service Marketplace MVP

A first development foundation for a multi-service marketplace launching in Singrauli, Madhya Pradesh.

## Included in this starter
- Flutter Android app foundation with Customer, Service Partner, and City Manager entry points
- Service category browsing and a sample booking flow
- Provider job/earnings dashboard sample
- City Manager operations dashboard sample
- Node.js API starter
- GitHub Actions workflow for cloud APK builds

## Important status
This is an MVP foundation, not a production-ready marketplace yet.
OTP login, real database persistence, payment gateway, provider verification, live maps,
notifications, refunds, and production security must be integrated and tested before public launch.
The current booking and earnings data are demonstration data.

## Build an APK with GitHub Actions
1. Upload the contents of this ZIP to a new GitHub repository (not the ZIP alone).
2. Open the **Actions** tab.
3. Run **Build SEVANEX Android APK** (or push to `main`).
4. Open the completed workflow run and download the `sevanex-debug-apk` artifact.
5. Install the APK on your Android phone for preview.

The workflow creates the Android platform folder using Flutter in the cloud.
No local Android SDK is required.

## Run the API locally
```bash
cd backend
npm install
npm start
```
The API starter listens on port 3000. It currently uses in-memory demo data.
